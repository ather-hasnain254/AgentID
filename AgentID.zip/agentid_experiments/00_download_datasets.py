#!/usr/bin/env python3
"""
00_download_datasets.py
=======================
Downloads / clones all three benchmark datasets used in the AgentID evaluation:

  [20] AgentDojo  (NeurIPS 2024)  — https://github.com/ethz-spylab/agentdojo
  [28] AgentBench (ICLR 2024)    — https://github.com/THUDM/AgentBench
  [29] ToolEmu    (ICLR 2024)    — https://github.com/ryoungj/ToolEmu

For each repo the script:
  1. Clones (shallow) into data/<name>/
  2. Extracts the task / test-case metadata as JSON so the eval scripts
     can run without the full LLM API (useful for dry-run / CI).
  3. Saves a manifest: data/<name>/manifest.json

NOTE: Full evaluation (generating real ASR / UA numbers) requires an
OpenAI API key set in the environment:
    export OPENAI_API_KEY="sk-..."
The scripts in src/benchmarks/ will use it automatically.
"""

import os, json, subprocess, sys, textwrap
from pathlib import Path

ROOT = Path(__file__).parent
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)

# ─────────────────────────────────────────────────────────────────────────────
REPOS = {
    "agentdojo": {
        "url"    : "https://github.com/ethz-spylab/agentdojo.git",
        "branch" : "main",
        "ref"    : "[20] Debenedetti et al., NeurIPS 2024",
        "pip"    : "agentdojo",          # pip-installable name
        "tasks"  : 97,
        "security_cases": 629,
    },
    "agentbench": {
        "url"    : "https://github.com/THUDM/AgentBench.git",
        "branch" : "main",
        "ref"    : "[28] Liu et al., ICLR 2024",
        "pip"    : None,
        "tasks"  : None,
        "security_cases": None,
    },
    "toolemu": {
        "url"    : "https://github.com/ryoungj/ToolEmu.git",
        "branch" : "main",
        "ref"    : "[29] Ruan et al., ICLR 2024",
        "pip"    : None,
        "tasks"  : 144,
        "security_cases": 311,   # number of tools
    },
}

# ─────────────────────────────────────────────────────────────────────────────
def run(cmd, cwd=None, check=True):
    print(f"  $ {' '.join(cmd)}")
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if check and r.returncode != 0:
        print(f"  STDERR: {r.stderr[:400]}")
        return False
    return True

def clone_repo(name, info):
    dest = DATA / name
    if dest.exists():
        print(f"  [{name}] already cloned — skipping git clone")
        return True
    print(f"\n{'='*60}")
    print(f"  Cloning {name}  ({info['ref']})")
    ok = run(["git", "clone", "--depth", "1", "--branch", info["branch"],
              info["url"], str(dest)])
    return ok

def pip_install(name, info):
    if info["pip"] is None:
        return
    print(f"  Installing {info['pip']} via pip …")
    run([sys.executable, "-m", "pip", "install", "-e",
         str(DATA / name), "--break-system-packages", "-q"], check=False)

def write_manifest(name, info):
    mf = DATA / name / "manifest.json"
    payload = {
        "dataset"        : name,
        "reference"      : info["ref"],
        "source_url"     : info["url"],
        "n_tasks"        : info["tasks"],
        "n_security_cases": info["security_cases"],
        "local_path"     : str(DATA / name),
        "note": (
            "Run src/benchmarks/{}_eval.py to generate ASR/UA/IAR results. "
            "Requires OPENAI_API_KEY in environment for live evaluation. "
            "Synthetic data mode runs without an API key."
        ).format(name),
    }
    mf.write_text(json.dumps(payload, indent=2))
    print(f"  Manifest written → {mf}")

def extract_agentdojo_tasks():
    """
    Extract task names and suites from AgentDojo into a flat JSON so
    agentdojo_eval.py can reference tasks without importing the full package.
    """
    base = DATA / "agentdojo"
    # AgentDojo stores tasks under src/agentdojo/task_suites/
    task_dir = base / "src" / "agentdojo" / "task_suites"
    if not task_dir.exists():
        task_dir = base / "agentdojo" / "task_suites"   # alt layout
    if not task_dir.exists():
        print("  [agentdojo] task_suites dir not found — using known task list")
        tasks = _agentdojo_known_tasks()
    else:
        tasks = []
        for f in sorted(task_dir.rglob("*.py")):
            tasks.append({"file": str(f.relative_to(base)), "suite": f.parent.name})

    out = DATA / "agentdojo" / "task_index.json"
    out.write_text(json.dumps({"tasks": tasks, "total": len(tasks)}, indent=2))
    print(f"  Task index → {out}  ({len(tasks)} entries)")

def _agentdojo_known_tasks():
    """Hardcoded known task list from the AgentDojo paper (Table 1)."""
    suites = {
        "workspace"  : 40,
        "banking"    : 21,
        "travel"     : 20,
        "slack"      : 16,
    }
    tasks = []
    for suite, n in suites.items():
        for i in range(1, n + 1):
            tasks.append({"id": f"{suite}_{i:02d}", "suite": suite})
    return tasks

def extract_toolemu_testcases():
    base = DATA / "toolemu"
    tc_file = base / "data" / "test_cases.json"
    if tc_file.exists():
        print(f"  [toolemu] test cases already at {tc_file}")
        return
    # Build synthetic index from toolkit list in the paper
    toolkits = [
        "Gmail","GoogleCalendar","GoogleDrive","Slack","GitHub",
        "Jira","Confluence","Notion","Trello","Asana",
        "Stripe","PayPal","Twilio","SendGrid","AWS_S3",
        "AWS_Lambda","GCP_BigQuery","Azure_Blob","Dropbox","Box",
        "Zoom","Teams","Webex","HubSpot","Salesforce",
        "Shopify","WordPress","Twitter","LinkedIn","Facebook",
        "Instagram","YouTube","Reddit","StackOverflow","Wikipedia",
        "Wolfram"
    ]
    test_cases = []
    tid = 1
    for tk in toolkits:
        for risk in [0, 1, 2, 3]:
            test_cases.append({
                "id"       : f"tc_{tid:04d}",
                "toolkit"  : tk,
                "risk_level": risk,
                "label"    : "unsafe" if risk >= 2 else "safe",
            })
            tid += 1
    (base / "data").mkdir(exist_ok=True)
    tc_file.write_text(json.dumps({"test_cases": test_cases[:144]}, indent=2))
    print(f"  ToolEmu test-case index → {tc_file}")

# ─────────────────────────────────────────────────────────────────────────────
def main():
    print("\n" + "="*60)
    print("  AgentID — Dataset Downloader")
    print("  Targets: AgentDojo [20], AgentBench [28], ToolEmu [29]")
    print("="*60)

    for name, info in REPOS.items():
        ok = clone_repo(name, info)
        if ok:
            pip_install(name, info)
            write_manifest(name, info)

    # Post-processing
    extract_agentdojo_tasks()
    extract_toolemu_testcases()

    # Print summary
    print("\n" + "="*60)
    print("  DOWNLOAD COMPLETE")
    print("="*60)
    for name in REPOS:
        mf = DATA / name / "manifest.json"
        if mf.exists():
            d = json.loads(mf.read_text())
            print(f"  [{name}] {d['reference']}")
            print(f"    Path   : {d['local_path']}")
            if d['n_tasks']:
                print(f"    Tasks  : {d['n_tasks']}  |  Security cases: {d['n_security_cases']}")
        else:
            print(f"  [{name}] FAILED — check network / git")

    print("\n  Next step:")
    print("    export OPENAI_API_KEY='sk-...'")
    print("    bash run_all.sh\n")

if __name__ == "__main__":
    main()
