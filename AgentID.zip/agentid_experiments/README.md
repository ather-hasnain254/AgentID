# AgentID — Full Experiment Codebase

## Structure
```
agentid_experiments/
├── README.md
├── run_all.sh                  ← single-command full pipeline
├── 00_download_datasets.py     ← download AgentDojo, AgentBench, ToolEmu
├── src/
│   ├── benchmarks/
│   │   ├── agentdojo_eval.py   ← Table VII/VIII (ASR, UA) vs [20] [9]
│   │   ├── agentbench_eval.py  ← Table IX (IAR) vs [28]
│   │   └── toolemu_eval.py     ← Table IX (Risk Rate) vs [29]
│   ├── crypto_bench/
│   │   └── crypto_microbench.py ← Table X (Ed25519, X25519, zlib latency)
│   └── visualization/
│       ├── fig1_pareto.py      ← Fig 1: ASR-vs-UA Pareto scatter (vs [20])
│       ├── fig2_latency.py     ← Fig 2: latency vs delegation depth
│       ├── fig3_throughput.py  ← Fig 3: VC throughput vs concurrency
│       ├── fig4_topology.py    ← Fig 4: topology impact CDF
│       ├── fig5_formal.py      ← Fig 5: capability lattice diagram
│       └── fig6_comparison.py  ← Fig 6: AgentID vs OAuth vs CanDID radar
├── data/                       ← downloaded datasets land here
└── results/
    ├── tables/                 ← CSV + LaTeX .tex files
    ├── figures/                ← PNG + PDF figures
    └── algorithms/             ← LaTeX algorithm blocks
```

## Quick Start
```bash
cd agentid_experiments
pip install -r requirements.txt
bash run_all.sh
```
All results appear in results/. Every [PH] in the paper maps to a file.
