#!/usr/bin/env python3
"""
src/visualization/fig_formal_comparison.py
===========================================
Generates the multi-dimensional comparison figures between AgentID
and the three comparison papers:
  [20] Debenedetti et al. AgentDojo    (NeurIPS 2024)
  [9]  Fett et al. OAuth 2.0           (ACM CCS 2016)
  [4]  Maram et al. CanDID             (IEEE S&P 2021)

Produces:
  results/figures/fig7_radar_comparison.png/.pdf   — Fig 7 (radar chart)
  results/figures/fig8_capability_lattice.png/.pdf — Fig 8 (capability lattice)
  results/tables/table_system_comparison.csv/.tex  — full system comparison table
  results/algorithms/algorithm3_acc_schema.tex     — Algorithm 3 (ACC schema)
"""

from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch
import matplotlib.patheffects as pe
import seaborn as sns
import pandas as pd

ROOT    = Path(__file__).parent.parent.parent
RESULTS = ROOT / "results"
TABLES  = RESULTS / "tables"
FIGS    = RESULTS / "figures"
for d in [TABLES, FIGS]: d.mkdir(parents=True, exist_ok=True)

# ─────────────────────────────────────────────────────────────────────────────
# FIGURE 7: Radar / Spider chart — multi-dimensional comparison
# Style: similar to comparison radars in blockchain/security papers
# ─────────────────────────────────────────────────────────────────────────────
def build_fig7_radar():
    """
    8-dimensional radar chart comparing AgentID, OAuth [9], and CanDID [4].
    Each axis is scored 0–10. Scores derived from published properties.
    """
    categories = [
        "Decen.\nIdentity",
        "Capability\nDelegation",
        "Formal\nProofs",
        "Model\nProvenance",
        "Revoc.\nFreshness",
        "Privacy\n(Pairwise)",
        "LLM Threat\nCoverage",
        "Issuance\nLatency\n(inverted)",
    ]
    N = len(categories)

    # Scores (0-10): higher = better
    systems = {
        "AgentID (Ours)"         : [10, 10, 9,  10, 8,  10, 10, 8],
        "OAuth 2.0 [9]"          : [ 1,  2, 8,   0, 3,   2,  1, 10],
        "CanDID [4]"             : [ 9,  1, 7,   0, 7,   8,  1,  2],
    }
    colors = {
        "AgentID (Ours)": "#003087",
        "OAuth 2.0 [9]" : "#D62728",
        "CanDID [4]"    : "#2CA02C",
    }

    angles = [n / float(N) * 2 * np.pi for n in range(N)]
    angles += angles[:1]

    fig, ax = plt.subplots(figsize=(7, 7), subplot_kw=dict(polar=True))
    ax.set_facecolor("#FAFAFA")

    for sys_name, vals in systems.items():
        v = vals + vals[:1]
        ax.plot(angles, v, "o-", lw=2.2, color=colors[sys_name],
                label=sys_name, ms=5)
        ax.fill(angles, v, alpha=0.10, color=colors[sys_name])

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories, fontsize=9.5)
    ax.set_yticks([2, 4, 6, 8, 10])
    ax.set_yticklabels(["2", "4", "6", "8", "10"], fontsize=7.5)
    ax.set_ylim(0, 10)

    ax.set_title(
        "Multi-Dimensional Security Capability Comparison\n"
        "AgentID vs. OAuth 2.0 [9] vs. CanDID [4]\n"
        "(Score 0–10; higher = better)",
        fontsize=10, pad=20
    )
    ax.legend(loc="lower right", bbox_to_anchor=(1.28, -0.05),
              fontsize=9.5, framealpha=0.9)

    plt.tight_layout()
    for ext in ["png", "pdf"]:
        p = FIGS / f"fig7_radar_comparison.{ext}"
        plt.savefig(p, dpi=180, bbox_inches="tight")
        print(f"  [Fig 7] {ext.upper()} → {p}")
    plt.close()

# ─────────────────────────────────────────────────────────────────────────────
# FIGURE 8: Capability Lattice Diagram
# ─────────────────────────────────────────────────────────────────────────────
def build_fig8_lattice():
    """
    Visualises the capability lattice (C, <=) for an example tool set
    T = {FlightSearch, FlightBook, EmailRead, EmailSend, BankTransfer}.
    Shows attenuation from orchestrator → sub-agents.
    """
    fig, ax = plt.subplots(figsize=(9, 6))
    ax.set_facecolor("#FAFAFA")
    ax.axis("off")
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 7)

    # Node definitions: (label, x, y, color, level)
    nodes = [
        ("T = {FS, FB, ER, ES, BT}",             5.0, 6.2, "#003087", "root"),
        ("{FS, FB, ER, ES}",                      2.5, 4.8, "#1F77B4", "l1"),
        ("{ER, ES, BT}",                          7.5, 4.8, "#1F77B4", "l1"),
        ("{FS, FB}",         1.2, 3.2, "#4C9BE8", "l2"),
        ("{ER, ES}",         3.8, 3.2, "#4C9BE8", "l2"),
        ("{ES, BT}",         6.2, 3.2, "#4C9BE8", "l2"),
        ("{BT}",             8.8, 3.2, "#4C9BE8", "l2"),
        ("{FS}",             0.6, 1.8, "#7FB8F0", "l3"),
        ("{FB}",             1.8, 1.8, "#7FB8F0", "l3"),
        ("{ER}",             3.2, 1.8, "#7FB8F0", "l3"),
        ("{ES}",             4.4, 1.8, "#7FB8F0", "l3"),
        ("{BT}*",            5.8, 1.8, "#7FB8F0", "l3"),
        ("∅",                5.0, 0.5, "#AAAAAA", "bot"),
    ]
    # Edges
    edges = [
        (0, 1), (0, 2),
        (1, 3), (1, 4),
        (2, 4), (2, 5), (2, 6),
        (3, 7), (3, 8),
        (4, 9), (4, 10),
        (5, 10), (5, 11),
        (6, 11),
        (7, 12), (8, 12), (9, 12), (10, 12), (11, 12),
    ]

    node_pos = {i: (n[1], n[2]) for i, n in enumerate(nodes)}

    for (u, v) in edges:
        x0, y0 = node_pos[u]
        x1, y1 = node_pos[v]
        ax.annotate("", xy=(x1, y1 + 0.25),
                    xytext=(x0, y0 - 0.25),
                    arrowprops=dict(
                        arrowstyle="-|>", color="#888888",
                        lw=1.2, mutation_scale=10))

    for i, (label, x, y, color, level) in enumerate(nodes):
        bbox_props = dict(boxstyle="round,pad=0.35", facecolor=color,
                          edgecolor="black", lw=0.8, alpha=0.92)
        fc = "white" if color not in ["#AAAAAA"] else "black"
        ax.text(x, y, label, ha="center", va="center",
                fontsize=8, color="white" if level != "bot" else "black",
                bbox=bbox_props, zorder=5)

    # Delegation annotations
    ax.annotate("Orchestrator a₀\n(trust tier 1)", xy=(5.0, 6.0),
                xytext=(8.2, 6.2), fontsize=8, color="#003087",
                arrowprops=dict(arrowstyle="->", color="#003087", lw=1.0))
    ax.annotate("Sub-agent a₁\n(travel booking)", xy=(1.2, 3.0),
                xytext=(-0.2, 2.0), fontsize=7.5, color="#1F77B4",
                arrowprops=dict(arrowstyle="->", color="#1F77B4", lw=0.9))
    ax.annotate("Sub-agent a₂\n(email compose)", xy=(3.8, 3.0),
                xytext=(3.5, 1.2), fontsize=7.5, color="#1F77B4",
                arrowprops=dict(arrowstyle="->", color="#1F77B4", lw=0.9))

    ax.set_title(
        "AgentID Capability Lattice  $(\\mathcal{C}, \\subseteq)$\n"
        "T = {FS=FlightSearch, FB=FlightBook, ER=EmailRead, ES=EmailSend, BT=BankTransfer}\n"
        "Monotonic attenuation: capabilities can only decrease down the lattice (Theorem 1)",
        fontsize=9.5, pad=10
    )

    plt.tight_layout()
    for ext in ["png", "pdf"]:
        p = FIGS / f"fig8_capability_lattice.{ext}"
        plt.savefig(p, dpi=180, bbox_inches="tight")
        print(f"  [Fig 8] {ext.upper()} → {p}")
    plt.close()

# ─────────────────────────────────────────────────────────────────────────────
# Full System Comparison Table (LaTeX + CSV)
# ─────────────────────────────────────────────────────────────────────────────
def build_system_comparison_table():
    rows = [
        ["Dimension",                "AgentID (Ours)",         "OAuth 2.0~[9]",            "CanDID~[4]"],
        ["Identity Model",           "Decentralized (DID)",    "Centralized (Auth Server)", "Decentralized (MPC)"],
        ["Credential Type",          "VC (W3C ACC)",           "JWT / Bearer Token",        "VC (legacy-attested)"],
        ["Capability Delegation",    "Full (4-phase protocol)","None",                      "None"],
        ["Cap. Attenuation Proof",   "Yes (Theorem 1, 2)",     "No",                        "No"],
        ["Model Provenance",         "Yes (modelProvenance)",  "No",                        "No"],
        ["Tool Scope Enforcement",   "Pre-LLM (Gateway)",      "None",                      "None"],
        ["Revocation",               "On-chain bitstring,480ms","Token introspection (sync)","Threshold on-chain"],
        ["Pairwise Privacy",         "Yes (did:peer)",         "No",                        "Partial"],
        ["Sybil Resistance",         "Via governance authority","Via AuthServer",            "Yes (MPC)"],
        ["Prompt Injection Defense", "Yes (formal)",           "None",                      "None"],
        ["Model Swapping Defense",   "Yes (provenance check)", "None",                      "None"],
        ["LLM Benchmark Eval.",      "AgentDojo, AgentBench,ToolEmu","None","None"],
        ["Issuance Latency",         "21 ms (Ed25519)",        "< 1 ms (HMAC sign)",        "\\approx 2500 ms (MPC)"],
        ["Venue",                    "IEEE TIFS (submitted)",  "ACM CCS 2016",              "IEEE S\\&P 2021"],
    ]
    df = pd.DataFrame(rows[1:], columns=rows[0])

    csv_path = TABLES / "table_system_comparison_full.csv"
    df.to_csv(csv_path, index=False)
    print(f"  [System Comp. Table] CSV  → {csv_path}")

    tex = r"""\begin{table*}[t]
\caption{Comprehensive system comparison: AgentID vs. OAuth~2.0~\cite{fett2016oauth}
vs. CanDID~\cite{maram2021candid}.
AgentID is the only system providing all five LLM-critical properties simultaneously:
capability delegation with formal proofs, model provenance binding,
pre-LLM tool-scope enforcement, prompt injection defense, and decentralized revocation.}
\label{tab:sysComp}
\centering
\small
\setlength{\tabcolsep}{5pt}
\begin{tabular}{l>{\raggedright}p{3.8cm}>{\raggedright}p{3.2cm}>{\raggedright\arraybackslash}p{3.2cm}}
\toprule
\textbf{Dimension} & \textbf{AgentID (Ours)} & \textbf{OAuth 2.0~\cite{fett2016oauth}} & \textbf{CanDID~\cite{maram2021candid}} \\
\midrule
"""
    highlight_rows = {
        "Cap. Attenuation Proof",
        "Model Provenance",
        "Tool Scope Enforcement",
        "Prompt Injection Defense",
        "Model Swapping Defense",
    }
    for _, row in df.iterrows():
        dim = row["Dimension"]
        cells = [row["AgentID (Ours)"], row["OAuth 2.0~[9]"], row["CanDID~[4]"]]
        if dim in highlight_rows:
            cells = [f"\\textbf{{{c}}}" if c not in ["No","None","No"] else f"\\textit{{{c}}}"
                     for c in cells]
        tex += f"{dim} & {cells[0]} & {cells[1]} & {cells[2]} \\\\\n"

    tex += r"""\bottomrule
\end{tabular}
\vspace{-2mm}
\end{table*}"""
    tex_path = TABLES / "table_system_comparison_full.tex"
    tex_path.write_text(tex)
    print(f"  [System Comp. Table] LaTeX → {tex_path}")

# ─────────────────────────────────────────────────────────────────────────────
# ALGORITHM 3: ACC Schema Validation (LaTeX)
# ─────────────────────────────────────────────────────────────────────────────
def build_algorithm3():
    algo = r"""\begin{algorithm}[t]
\caption{AgentCapabilityCredential (ACC) Schema and Validation}
\label{alg:acc_schema}
\begin{algorithmic}[1]
\Require ACC JSON-LD document $\mathcal{A}$, verifier time $\tau_{\text{now}}$,
         requested tool $t$, Fabric VDR $\mathcal{L}$

\Statex \textbf{Schema fields} (all required):
\State $\mathcal{A}.\texttt{type} \supseteq \{$\texttt{"VerifiableCredential"}, \texttt{"AgentCapabilityCredential"}\}$
\State $\mathcal{A}.\texttt{issuer} \in \text{did:web}^*$
\State $\mathcal{A}.\texttt{credentialSubject.id} \in \text{did:peer}^* \cup \text{did:web}^*$
\State $\mathcal{A}.\texttt{credentialSubject.modelProvenance} = (m_{\text{id}}, h, \text{did}_{\text{att}})$
\State $\mathcal{A}.\texttt{credentialSubject.authorizedToolClasses} \subseteq \mathcal{T}$
\State $\mathcal{A}.\texttt{credentialSubject.trustTier} \in \{0,1,2,3\}$
\State $\mathcal{A}.\texttt{credentialSubject.delegationDepth} \in \mathbb{Z}_{\geq 0}$
\State $\mathcal{A}.\texttt{credentialSubject.maxDelegationDepth} \in \mathbb{Z}_{>0}$
\State $\mathcal{A}.\texttt{credentialSubject.revocationRegistry} \in \text{URI}^*$
\State $\mathcal{A}.\texttt{proof.type} = \texttt{"Ed25519Signature2020"}$

\Statex \textbf{Validation procedure} \textsc{ValidateACC}($\mathcal{A}$, $t$, $\tau_{\text{now}}$, $\mathcal{L}$):
\State $\text{DIDDoc} \leftarrow \textsc{ResolveDID}(\mathcal{A}.\texttt{issuer})$
\If{$\text{DIDDoc} = \bot$} \Return \textsf{INVALID\_ISSUER} \EndIf
\State $vk \leftarrow \text{DIDDoc}.\text{verificationMethod}[\texttt{Ed25519}]$
\State $m \leftarrow \textsc{JCS\_Serialize}(\mathcal{A}.\text{body})$
\If{$\textsc{Ed25519Verify}(vk, m, \mathcal{A}.\texttt{proof.proofValue}) \neq 1$}
  \Return \textsf{INVALID\_SIGNATURE}
\EndIf
\State $b \leftarrow \textsc{FabricQuery}(\mathcal{L}, \mathcal{A}.\texttt{revocationRegistry})$
\If{$b[\mathcal{A}.\texttt{statusIndex}] = 1$} \Return \textsf{REVOKED} \EndIf
\If{$\tau_{\text{now}} > \mathcal{A}.\texttt{expirationDate}$} \Return \textsf{EXPIRED} \EndIf
\If{$\mathcal{A}.\texttt{delegationDepth} > \mathcal{A}.\texttt{maxDelegationDepth}$}
  \Return \textsf{DEPTH\_EXCEEDED}
\EndIf
\If{$\textsc{ToolClass}(t) \notin \mathcal{A}.\texttt{authorizedToolClasses}$}
  \Return \textsf{CAPABILITY\_DENIED}
\EndIf
\Return \textsf{AUTHORIZED}
\end{algorithmic}
\end{algorithm}"""

    alg_path = RESULTS / "algorithms" / "algorithm3_acc_schema.tex"
    alg_path.parent.mkdir(exist_ok=True)
    alg_path.write_text(algo)
    print(f"  [Algorithm 3] LaTeX → {alg_path}")

# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────
def main():
    print("\n" + "="*60)
    print("  Formal Comparison Figures")
    print("  vs [9] Fett et al., [4] Maram et al., [20] Debenedetti et al.")
    print("="*60)

    print("\n  Building Figure 7 (radar comparison) …")
    build_fig7_radar()

    print("\n  Building Figure 8 (capability lattice) …")
    build_fig8_lattice()

    print("\n  Building full system comparison table …")
    build_system_comparison_table()

    print("\n  Building Algorithm 3 (ACC schema validation) …")
    build_algorithm3()

    print("\n  Done.")

if __name__ == "__main__":
    main()
