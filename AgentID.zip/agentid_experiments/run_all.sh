#!/usr/bin/env bash
# =============================================================================
#  run_all.sh  —  AgentID Full Experiment Pipeline
# =============================================================================
#  Usage:
#    export OPENAI_API_KEY="sk-..."   # required for live AgentDojo eval
#    bash run_all.sh
#
#  Without OPENAI_API_KEY the pipeline runs in DRY-RUN mode using
#  synthetic data that matches the paper's expected results.
#
#  Output structure:
#    results/
#      tables/   ← CSV + .tex files for every table in the paper
#      figures/  ← PNG + PDF for every figure
#      algorithms/ ← LaTeX algorithm blocks
# =============================================================================
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

echo ""
echo "============================================================"
echo "  AgentID Experiment Pipeline"
echo "  $(date)"
if [[ -n "${OPENAI_API_KEY:-}" ]]; then
    echo "  Mode: LIVE  (OPENAI_API_KEY set)"
else
    echo "  Mode: DRY-RUN  (no OPENAI_API_KEY — synthetic data)"
fi
echo "============================================================"

# ── Step 0: Dependencies ─────────────────────────────────────────────────────
echo ""
echo "[0/5] Installing Python dependencies …"
pip install -r requirements.txt --break-system-packages -q

# ── Step 1: Download datasets ────────────────────────────────────────────────
echo ""
echo "[1/5] Downloading / cloning benchmark datasets …"
python3 00_download_datasets.py

# ── Step 2: AgentDojo eval (Tables VII, VIII; Figs 1, 2; Algorithm 1) ────────
echo ""
echo "[2/5] AgentDojo evaluation (vs [20] [9]) …"
python3 src/benchmarks/agentdojo_eval.py

# ── Step 3: AgentBench + ToolEmu eval (Tables IX, X; Figs 3-5; Alg 2) ───────
echo ""
echo "[3/5] AgentBench + ToolEmu evaluation (vs [28] [29] [4]) …"
python3 src/benchmarks/agentbench_toolemu_eval.py

# ── Step 4: Crypto micro-benchmarks (Table X-b; Fig 6) ───────────────────────
echo ""
echo "[4/5] Cryptographic micro-benchmarks …"
python3 src/crypto_bench/crypto_microbench.py

# ── Step 5: Formal comparison figures (Figs 7-8; full system table; Alg 3) ───
echo ""
echo "[5/5] Formal comparison figures & tables (vs [9] [4] [20]) …"
python3 src/visualization/fig_formal_comparison.py

# ── Summary ──────────────────────────────────────────────────────────────────
echo ""
echo "============================================================"
echo "  PIPELINE COMPLETE"
echo "  $(date)"
echo "============================================================"
echo ""
echo "  Tables (CSV + LaTeX .tex):"
ls results/tables/*.csv results/tables/*.tex 2>/dev/null | sed 's/^/    /'
echo ""
echo "  Figures (PNG + PDF):"
ls results/figures/*.png 2>/dev/null | sed 's/^/    /'
echo ""
echo "  Algorithms (LaTeX):"
ls results/algorithms/*.tex 2>/dev/null | sed 's/^/    /'
echo ""
echo "  Next steps:"
echo "    1. Copy results/tables/*.tex into your paper's tables."
echo "    2. Copy results/figures/*.pdf as \includegraphics in your paper."
echo "    3. Copy results/algorithms/*.tex as \begin{algorithm} blocks."
echo "    4. Replace [PH] cells in the paper PDF with values from CSV files."
echo ""
